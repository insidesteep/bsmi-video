import dbConnect from "../../lib/dbConnect";
import Author from "../../models/author.model";

export default async function handler(req, res) {
  const { method } = req;

  await dbConnect();

  switch (method) {
    case "GET":
      try {
        const authors = await Author.find({});

        Author.countDocuments({}, function (err, c) {
          res.status(200).json({ success: true, data: { authors, count: c } });
        });
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;

    case "POST":
      try {
        const { firstname, lastname, patronymic } = req.body;

        const author = await Author.findOne({
          firstname,
          lastname,
          patronymic,
        });

        if (author) {
          res.status(400).json({ success: false, message: "" });
        }

        await Author.create({
          firstname,
          lastname,
          patronymic,
        });

        const authors = await Author.find({});

        let count = 0;

        Author.countDocuments({}, function (err, c) {
          count = c;
        });

        res.status(200).json({ success: true, data: { authors, count } });
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;

    default:
      res.status(400).json({ success: false });
      break;
  }
}
