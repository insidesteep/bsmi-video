import dbConnect from "../../../lib/dbConnect";
import Video from "../../../models/video.model";
import Category from "../../../models/category.model";

export default async function handler(req, res) {
  const { method } = req;

  await dbConnect();

  switch (method) {
    case "GET":
      try {
        const videos = await Video.find({})
          .select("-category -description -youtubeId")
          .populate({
            path: "author",
            model: "Author",
            select: "-_id",
          });

        res.status(200).json({ success: true, data: videos });
      } catch (error) {
        console.log(error);
        res.status(400).json({ success: false });
      }
      break;

    case "POST":
      try {
        // const videos = await Video.find({});

        const {
          title,
          description,
          thumbnail,
          youtubeId,
          viewCount,
          duration,
          author,
          category,
        } = req.body;

        const isExistVideo = await Video.findOne({ youtubeId });

        if (isExistVideo) {
          res
            .status(400)
            .json({ success: false, message: "Видео уже было сохранено!" });
        }

        let ctg = await Category.findOne({
          playlistId: category.id,
        });

        if (!ctg) {
          ctg = new Category({
            name: category.name,
            playlistId: category.playlistId,
          });
        }

        const video = new Video({
          title,
          description,
          thumbnail,
          youtubeId,
          viewCount,
          duration,
          author,
        });

        ctg.videos.push(video._id);
        video.category = ctg._id;

        await ctg.save();
        await video.save();

        res
          .status(200)
          .json({ success: true, message: "Видео успешно сохранено" });
      } catch (error) {
        console.log(error);
        res
          .status(400)
          .json({ success: false, message: "Ошибка при сохранении видео" });
      }
      break;

    default:
      res.status(400).json({ success: false });
      break;
  }
}
